<?php
$pass = password_hash("admin123", PASSWORD_DEFAULT);
echo $pass;
?>
